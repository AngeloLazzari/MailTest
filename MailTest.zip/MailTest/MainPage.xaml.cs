﻿using Microsoft.Maui.Controls;
using System.Diagnostics;
using static System.Net.Mime.MediaTypeNames;

namespace MailTest
{
    public partial class MainPage : ContentPage
    {
        int count = 0;

        public MainPage()
        {
            InitializeComponent();
        }

        private async void OnCounterClicked(object sender, EventArgs e)
        {


            var fn = "Attachment.txt";
            var file = Path.Combine(FileSystem.CacheDirectory, fn);
            File.WriteAllText(file, "Hello World");


            /*string path = FileSystem.Current.CacheDirectory;
            string DataFile = @"testclass.cs";

            string filePath = Path.Combine(path, DataFile);*/

            EmailMessage message = new EmailMessage();

            string[] recipients = new[] { "lazzari.angelo@gmail.com"};




                message.To = new List<string>(recipients);

                message.Attachments = new List<EmailAttachment>() { new EmailAttachment(file) };

                message.Subject = "TEST MAIL";

                await Email.Default.ComposeAsync(message);
            
        }
    }

}
